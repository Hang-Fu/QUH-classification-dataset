close all;
clear all;clc
addpath(genpath('.\superpixel'));
addpath(genpath('.\tcSVD-master'));
addpath(genpath('.\libsvm-3.18'));

%Data 1
load('indian_pines_gt'); img_gt=indian_pines_gt;
map=label2color(img_gt,'india');figure,imshow(map);
load('Indian_pines_corrected');img=indian_pines_corrected;
[W,H,B]=size(img);

%% oriHSIdata+RCSPP
win=20; win2=win*win;
numS=ceil(W*H/win2);
[Sp,~]=SuperpixelSegmentation(img,numS);
numSuperpixels=max(Sp(:));

%% Sup-3DSSA
img_Sup3D=zeros(W,H,B);

Mark=1;   %mean or neigbor pixels
tic;
for i=1:numSuperpixels
    u=5;v=u;b=u;
    index=find(Sp==i);
    [r,c]=find(Sp==i);
    minr=min(r);maxr=max(r);   row=length(min(r):max(r)); 
    minc=min(c);maxc=max(c);   col=length(min(c):max(c));
    sub_Sp=Sp(minr:maxr,minc:maxc);
    subindex=find(sub_Sp==i);
    
    temp_img=zeros(W,H,B);
    img3D=zeros(W*H,B);
    sub_img=img(minr:maxr,minc:maxc,:);
    switch Mark
        case 1  %mean
            sub_img0=sub_img;
            
        case 2  %neigbor
            sub_img=reshape(sub_img,[row*col,B]);
            sub_img0=repmat(mean(sub_img(subindex,:)),[row*col,1]); %����ֵ
            sub_img0(subindex,:)=sub_img(subindex,:);
            sub_img0=reshape(sub_img0,[row,col,B]);
    end
    
    %perform 3DSSA
    if min(row,col)<=(2*u-1)
        u=floor(min(row,col)/2);
        v=u;b=u;
    end

    rec_subimg=fast_SSA_3Ds(sub_img0,u,v,b,row,col,B);
    temp_img(minr:maxr,minc:maxc,:)=rec_subimg;
    temp_img=reshape(temp_img,[W*H,B]);
    img3D(index,:)=temp_img(index,:);
    img3D=reshape(img3D,[W,H,B]);
    
    img_Sup3D=img_Sup3D+img3D;
    toc;
end
toc;

%% ==================classification=================
Vectors=reshape(img_Sup3D,W*H,B);
% training samples
load('IP_training');
train=label2color(IP_training,'india');figure;imshow(train);%imwrite(train,'C:\Users\rjceh\Desktop\IP_train.tif');
train_index=find(IP_training~=0);
trainVectors=Vectors(train_index,:);
trainLabels=nonzeros(IP_training(:));
% testing samples
load('IP_testing');
test=label2color(IP_testing,'india');figure;imshow(test);%imwrite(test,'C:\Users\rjceh\Desktop\IP_test.tif');
test_index=find(IP_testing~=0);
testVectors=Vectors(test_index,:);
testLabels=nonzeros(IP_testing(:));

[trainVectors,M,m] = scale_func(trainVectors); 
[testVectors ] = scale_func(testVectors,M,m);  
[Vectors ] = scale_func(Vectors,M,m); 
Ccv=1250; Gcv=0.125;
cmd=sprintf('-c %f -g %f -m 500 -t 2 -q',Ccv,Gcv); 
models        =  svmtrain(trainLabels,trainVectors,cmd);
testLabel_est =  svmpredict(testLabels,testVectors, models);

%accuracy
[OA,AA,kappa,CA]=confusion(testLabels,testLabel_est);
Acc=[OA*100;AA*100;kappa];

%classification map
labels = IP_testing+IP_training;
labels = labels(:);
SVMresult = svmpredict(labels,Vectors,models); 
SVMresult = reshape(SVMresult,W,H);
SVMmap = label2color(SVMresult,'india');figure,imshow(SVMmap);

