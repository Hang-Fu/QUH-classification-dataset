function HSI=fast_SSA_3Ds(img,u,v,b,W,H,B)
%��������cube
X=zeros(u*v*b,(W-u+1)*(H-v+1),B-b+1);
HSI=zeros(W,H,B);
for k=1:(B-b+1)
    n=1;
    for i=1:(W-u+1)
        for j=1:(H-v+1)
            test=img(i:(i+u-1),j:(j+v-1),k:(k+b-1));
            col=test(:);
            X(:,n,k)=col;
            n=n+1;
        end
    end
end
[~,col,~]=size(X);


% %T-SVD�ֽ�
% r=1;
% [U,S,V] = tSVD(X,r);clear X;
% C = tProdact(U,S);
% VV=tTranspose(V);
% Cube=tProdact(C,VV);
% clear U;clear S;clear V;clear VV;clear C;

%����TSVD�ֽ�
X_respresent=mean(X,3);
r=1;
[U] = tSVD_fast3DSSA(X_respresent,r);
U=real(U);
Cube=zeros(u*v*b,(W-u+1)*(H-v+1),B-b+1);
U2=U*U';
for k=1:(B-b+1)
    Cube(:,:,k)=U2*X(:,:,k);
end

%�Ȳ��ζԽ�ƽ�����ٿռ�Խ�ƽ��
Y=zeros(u*v,col,B);
for n=1:b
    for j=1:n
        Y(:,:,n)=Y(:,:,n)+(1/n)*Cube((j-1)*u*v+1:j*u*v,:,n-j+1);
    end
end
for n=b+1:(B-b)
    for j=1:b
        Y(:,:,n)=Y(:,:,n)+(1/b)*Cube((j-1)*u*v+1:j*u*v,:,n-j+1);
    end
end
for n=(B-b+1):B
    for j=n-(B-b+1)+1:b
        Y(:,:,n)=Y(:,:,n)+(1/(B-n+1))*Cube((j-1)*u*v+1:j*u*v,:,n-j+1);
    end
end
for i=1:B
    HSI(:,:,i)=hankel_bet(Y(:,:,i),u,v,W,H);
end