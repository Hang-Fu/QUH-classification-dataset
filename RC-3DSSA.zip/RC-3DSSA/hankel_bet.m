function [y]=hankel_bet(rca,u,v,h,w)
% Reconstruction between block function

   L=u;
   K=h-u+1;
   N=h;
   y=zeros(N,w);  
   Lp=min(L,K);
   Kp=max(L,K);
   for k=0:Lp-2
     for m=1:k+1;
      y(k+1,:)=y(k+1,:)+(1/(k+1))*hankel_wit(rca(((m-1)*v+1):(m*v),((k-m+1)*(w-v+1)+1):((k-m+2)*(w-v+1))),v,w); %(m,k-m+2)
     end
   end
   for k=Lp-1:Kp-1
     for m=1:Lp;
      y(k+1,:)=y(k+1,:)+(1/(Lp))*hankel_wit(rca(((m-1)*v+1):(m*v),((k-m+1)*(w-v+1)+1):((k-m+2)*(w-v+1))),v,w); %(m,k-m+2)
     end
   end
   for k=Kp:N
      for m=k-Kp+2:N-Kp+1;
       y(k+1,:)=y(k+1,:)+(1/(N-k))*hankel_wit(rca(((m-1)*v+1):(m*v),((k-m+1)*(w-v+1)+1):((k-m+2)*(w-v+1))),v,w); %(m,k-m+2)
     end
   end

end

function [y]=hankel_wit(rca,v,w)
% Reconstruction within block function
% block�ڲ����˻������
L=v;
K=w-v+1;
N=w;
y=zeros(1,N);
Lp=min(L,K);
Kp=max(L,K);

for k=0:Lp-2
    for m=1:k+1;
        y(k+1)=y(k+1)+(1/(k+1))*rca(m,k-m+2);
    end
end
for k=Lp-1:Kp-1
    for m=1:Lp;
        y(k+1)=y(k+1)+(1/(Lp))*rca(m,k-m+2);
    end
end
for k=Kp:N
    for m=k-Kp+2:N-Kp+1;
        y(k+1)=y(k+1)+(1/(N-k))*rca(m,k-m+2);
    end
end

end