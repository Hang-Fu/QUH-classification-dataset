%% A code for TSVD
function [U] = tSVD_fast3DSSA(A,r)
    D=fft(A,[],3);
    [U,~,~]=svds(double(D),r);
        
%     DD=double(D)*double(D)';
%     [U,~]=eigs(DD,r);

    U=ifft(U,[],3);
end