# L_SVD_Coding

We implement the L_SVD tensor decomposition:

1) L_SVD decomposition with the transform being fft, dct, dwt

2) L_SVD compress for videos
