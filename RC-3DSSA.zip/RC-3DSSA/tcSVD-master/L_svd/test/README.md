1、The t_svd_test.py demonstrates the L_svd in fft,can see the error between the original and reconstracted data<br>
![](https://github.com/hust512/tensorly/blob/master/tensorly/L_svd/test/L_SVD_reconstructed.png?raw=true "reconstract&original")<br>
2、The tSVD_compress.py compute the relative square error (RSE) comparison for different compression ratio.The result show in follow.<br>
![](https://github.com/hust512/tensorly/blob/master/tensorly/L_svd/test/Compress.png?raw=true "compress result")
