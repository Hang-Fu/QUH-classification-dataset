a new approch in tensor decompose ,

soon add classification and cluster method